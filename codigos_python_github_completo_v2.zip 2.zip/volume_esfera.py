# Cálculo do volume de uma esfera
R = int(input())

pi = 3.14159
volume = (4 / 3) * pi * R ** 3

print(f"VOLUME = {volume:.3f}")
