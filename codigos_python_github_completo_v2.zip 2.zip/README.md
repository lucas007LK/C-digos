# Meus Exercícios e Códigos em Python 🚀

Repositório criado para armazenar meus estudos, lógica de programação e algoritmos desenvolvidos durante minha jornada em Tecnologia da Informação.

## 📂 Lista de Exercícios Incluídos:
* `valida_numero.py`: Validação de número entre 1 e 10 usando loop `while`.
* `valida_senha.py`: Sistema simples de checagem de senha.
* `dias_treino.py`: Lista interativa de dias da semana para escolha de treino.
* `converte_dias.py`: Conversor de dias totais em anos, meses e dias.
* `converte_segundos.py`: Conversor de segundos totais em formato de horas, minutos e segundos.
* `calcula_cedulas.py`: Simulador de caixa eletrônico para cálculo de cédulas e notas.
* `combustivel_viagem.py`: Cálculo de litros de combustível consumidos em uma viagem.
* `calcula_tempo_distancia.py`: Conversão de distância em minutos proporcionais.
* `distancia_pontos.py`: Cálculo matemático de distância Euclidiana entre dois pontos.
* `consumo_combustivel.py`: Cálculo de consumo médio de combustível (km/l).
* `maior_tres_numeros.py`: Algoritmo para encontrar o maior entre três números inteiros.
* `areas_geometricas.py`: Cálculo de áreas de triângulo, círculo, trapézio, quadrado e retângulo.
* `soma_simples.py`: Soma simples entre dois valores inteiros.
* `volume_esfera.py`: Cálculo do volume de uma esfera dado o raio.
* `valor_pecas.py`: Cálculo do valor total a pagar por peças compradas.
* `salario_vendedor.py`: Cálculo de salário com comissão de vendas.
* `salario_horas.py`: Cálculo de salário baseado em horas trabalhadas.
* `diferenca_produtos.py`: Cálculo da diferença do produto de quatro valores.
* `media_ponderada.py`: Cálculo de média ponderada de notas.

---
Desenvolvido por Lucas Gonçalves Ursino
