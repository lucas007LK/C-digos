# Soma simples de dois valores (Extremamente Básico)
A = int(input())
B = int(input())

X = A + B

print(f"X = {X}")
