# Meus Exercícios e Códigos em Python 🚀

Repositório criado para armazenar meus estudos, lógica de programação e algoritmos desenvolvidos durante minha jornada em Tecnologia da Informação.

## 📂 Conteúdos Incluídos:
* `valida_numero.py`: Validação de número entre 1 e 10 usando loop `while`.
* `valida_senha.py`: Sistema simples de checagem de senha.
* `dias_treino.py`: Lista interativa de dias da semana para escolha de treino.
* `converte_dias.py`: Conversor de dias totais em anos, meses e dias.
* `converte_segundos.py`: Conversor de segundos totais em formato de horas, minutos e segundos.
* `calcula_cedulas.py`: Simulador de caixa eletrônico para cálculo de cédulas e notas.
* `combustivel_viagem.py`: Cálculo de litros de combustível consumidos em uma viagem.
* `calcula_tempo_distancia.py`: Conversão de distância em minutos proporcionais.
* `distancia_pontos.py`: Cálculo matemático de distância Euclidiana entre dois pontos no plano cartesiano.

---
Desenvolvido por Lucas Gonçalves Ursino
